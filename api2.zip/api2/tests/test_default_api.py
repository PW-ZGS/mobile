# coding: utf-8

from fastapi.testclient import TestClient


from openapi_server.models.driver_route import DriverRoute  # noqa: F401
from openapi_server.models.driver_routes_from_post200_response import DriverRoutesFromPost200Response  # noqa: F401
from openapi_server.models.driver_routes_route_id_post200_response import DriverRoutesRouteIdPost200Response  # noqa: F401
from openapi_server.models.driver_routes_route_id_post_request import DriverRoutesRouteIdPostRequest  # noqa: F401
from openapi_server.models.matches_get200_response_inner import MatchesGet200ResponseInner  # noqa: F401
from openapi_server.models.offices_get200_response_inner import OfficesGet200ResponseInner  # noqa: F401
from openapi_server.models.passenger_route import PassengerRoute  # noqa: F401
from openapi_server.models.passenger_route_input import PassengerRouteInput  # noqa: F401
from openapi_server.models.passenger_routes_from_post200_response import PassengerRoutesFromPost200Response  # noqa: F401
from openapi_server.models.passengers_get200_response import PassengersGet200Response  # noqa: F401
from openapi_server.models.route_input import RouteInput  # noqa: F401
from openapi_server.models.users_post200_response import UsersPost200Response  # noqa: F401
from openapi_server.models.users_post_request import UsersPostRequest  # noqa: F401


def test_driver_routes_by_users_user_id_get(client: TestClient):
    """Test case for driver_routes_by_users_user_id_get

    Get Driver's Routes
    """

    headers = {
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/driver_routes/by-users/{userId}".format(userId='user_id_example'),
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_driver_routes_from_post(client: TestClient):
    """Test case for driver_routes_from_post

    Create DriverRoute (From)
    """
    route_input = {"office_id":"officeId","available_seats":0,"start_point":{"latitude":0.8008281904610115,"longitude":6.027456183070403},"from_time":"2000-01-23T04:56:07.000+00:00","user_id":"userId"}

    headers = {
    }
    # uncomment below to make a request
    #response = client.request(
    #    "POST",
    #    "/driver_routes/from",
    #    headers=headers,
    #    json=route_input,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_driver_routes_route_id_delete(client: TestClient):
    """Test case for driver_routes_route_id_delete

    Delete DriverRoute
    """

    headers = {
    }
    # uncomment below to make a request
    #response = client.request(
    #    "DELETE",
    #    "/driver_routes/{routeId}".format(routeId='route_id_example'),
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_driver_routes_route_id_get(client: TestClient):
    """Test case for driver_routes_route_id_get

    Get DriverRoute
    """

    headers = {
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/driver_routes/{routeId}".format(routeId='route_id_example'),
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_driver_routes_route_id_post(client: TestClient):
    """Test case for driver_routes_route_id_post

    Modify Passenger Count
    """
    driver_routes_route_id_post_request = openapi_server.DriverRoutesRouteIdPostRequest()

    headers = {
    }
    # uncomment below to make a request
    #response = client.request(
    #    "POST",
    #    "/driver_routes/{routeId}".format(routeId='route_id_example'),
    #    headers=headers,
    #    json=driver_routes_route_id_post_request,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_driver_routes_to_post(client: TestClient):
    """Test case for driver_routes_to_post

    Create DriverRoute (To)
    """
    route_input = {"office_id":"officeId","available_seats":0,"start_point":{"latitude":0.8008281904610115,"longitude":6.027456183070403},"from_time":"2000-01-23T04:56:07.000+00:00","user_id":"userId"}

    headers = {
    }
    # uncomment below to make a request
    #response = client.request(
    #    "POST",
    #    "/driver_routes/to",
    #    headers=headers,
    #    json=route_input,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_matches_get(client: TestClient):
    """Test case for matches_get

    Get Matches by DriverRoute ID
    """
    params = [("passenger_route_id", 'passenger_route_id_example')]
    headers = {
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/matches",
    #    headers=headers,
    #    params=params,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_offices_get(client: TestClient):
    """Test case for offices_get

    Get List of Offices
    """

    headers = {
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/offices",
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_passenger_routes_by_users_user_id_get(client: TestClient):
    """Test case for passenger_routes_by_users_user_id_get

    Get Driver's PassengerRoutes
    """

    headers = {
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/passenger_routes/by-users/{userId}".format(userId='user_id_example'),
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_passenger_routes_from_post(client: TestClient):
    """Test case for passenger_routes_from_post

    Create PassengerRoute (From)
    """
    passenger_route_input = {"max_dist":1,"office_id":"officeId","start_point":{"latitude":0.8008281904610115,"longitude":6.027456183070403},"time_range":{"end_date":6,"start_date":0}}

    headers = {
    }
    # uncomment below to make a request
    #response = client.request(
    #    "POST",
    #    "/passenger_routes/from",
    #    headers=headers,
    #    json=passenger_route_input,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_passenger_routes_passenger_route_id_delete(client: TestClient):
    """Test case for passenger_routes_passenger_route_id_delete

    Delete DriverRoute
    """

    headers = {
    }
    # uncomment below to make a request
    #response = client.request(
    #    "DELETE",
    #    "/passenger_routes/{passengerRouteId}".format(passengerRouteId='passenger_route_id_example'),
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_passenger_routes_passenger_route_id_get(client: TestClient):
    """Test case for passenger_routes_passenger_route_id_get

    Get PassengerRoute
    """

    headers = {
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/passenger_routes/{passengerRouteId}".format(passengerRouteId='passenger_route_id_example'),
    #    headers=headers,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_passenger_routes_to_post(client: TestClient):
    """Test case for passenger_routes_to_post

    Create PassengerRoute (To)
    """
    passenger_route_input = {"max_dist":1,"office_id":"officeId","start_point":{"latitude":0.8008281904610115,"longitude":6.027456183070403},"time_range":{"end_date":6,"start_date":0}}

    headers = {
    }
    # uncomment below to make a request
    #response = client.request(
    #    "POST",
    #    "/passenger_routes/to",
    #    headers=headers,
    #    json=passenger_route_input,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_passengers_get(client: TestClient):
    """Test case for passengers_get

    Get Waiting Place Information
    """
    params = [("contact", 'contact_example'),     ("user_id", 'user_id_example')]
    headers = {
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/passengers",
    #    headers=headers,
    #    params=params,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_users_post(client: TestClient):
    """Test case for users_post

    Create User Account
    """
    users_post_request = openapi_server.UsersPostRequest()

    headers = {
    }
    # uncomment below to make a request
    #response = client.request(
    #    "POST",
    #    "/users",
    #    headers=headers,
    #    json=users_post_request,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200


def test_users_validation_get(client: TestClient):
    """Test case for users_validation_get

    Validate User
    """
    params = [("user_id", 'user_id_example')]
    headers = {
    }
    # uncomment below to make a request
    #response = client.request(
    #    "GET",
    #    "/users/validation",
    #    headers=headers,
    #    params=params,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200

