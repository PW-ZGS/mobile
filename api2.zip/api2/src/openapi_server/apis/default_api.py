# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil

from openapi_server.apis.default_api_base import BaseDefaultApi
import openapi_server.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    Path,
    Query,
    Response,
    Security,
    status,
)

from openapi_server.models.extra_models import TokenModel  # noqa: F401
from openapi_server.models.driver_route import DriverRoute
from openapi_server.models.driver_routes_from_post200_response import DriverRoutesFromPost200Response
from openapi_server.models.driver_routes_route_id_post200_response import DriverRoutesRouteIdPost200Response
from openapi_server.models.driver_routes_route_id_post_request import DriverRoutesRouteIdPostRequest
from openapi_server.models.matches_get200_response_inner import MatchesGet200ResponseInner
from openapi_server.models.offices_get200_response_inner import OfficesGet200ResponseInner
from openapi_server.models.passenger_route import PassengerRoute
from openapi_server.models.passenger_route_input import PassengerRouteInput
from openapi_server.models.passenger_routes_from_post200_response import PassengerRoutesFromPost200Response
from openapi_server.models.passengers_get200_response import PassengersGet200Response
from openapi_server.models.route_input import RouteInput
from openapi_server.models.users_post200_response import UsersPost200Response
from openapi_server.models.users_post_request import UsersPostRequest


router = APIRouter()

ns_pkg = openapi_server.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)


@router.get(
    "/driver_routes/by-users/{userId}",
    responses={
        200: {"model": List[DriverRoute], "description": "List of driver&#39;s routes"},
    },
    tags=["default"],
    summary="Get Driver&#39;s Routes",
    response_model_by_alias=True,
)
async def driver_routes_by_users_user_id_get(
    userId: str = Path(..., description=""),
) -> List[DriverRoute]:
    """Retrieves a list of routes reported by the driver, with optional filtering by userId."""
    return BaseDefaultApi.subclasses[0]().driver_routes_by_users_user_id_get(userId)


@router.post(
    "/driver_routes/from",
    responses={
        200: {"model": DriverRoutesFromPost200Response, "description": "DriverRoute created successfully"},
    },
    tags=["default"],
    summary="Create DriverRoute (From)",
    response_model_by_alias=True,
)
async def driver_routes_from_post(
    route_input: RouteInput = Body(None, description=""),
) -> DriverRoutesFromPost200Response:
    """Creates a new route with a starting point (office) and specified details."""
    return BaseDefaultApi.subclasses[0]().driver_routes_from_post(route_input)


@router.delete(
    "/driver_routes/{routeId}",
    responses={
        204: {"description": "DriverRoute deleted successfully"},
    },
    tags=["default"],
    summary="Delete DriverRoute",
    response_model_by_alias=True,
)
async def driver_routes_route_id_delete(
    routeId: str = Path(..., description=""),
) -> None:
    """Deletes the specified route."""
    return BaseDefaultApi.subclasses[0]().driver_routes_route_id_delete(routeId)


@router.get(
    "/driver_routes/{routeId}",
    responses={
        200: {"model": DriverRoute, "description": "DriverRoute"},
    },
    tags=["default"],
    summary="Get DriverRoute",
    response_model_by_alias=True,
)
async def driver_routes_route_id_get(
    routeId: str = Path(..., description=""),
) -> DriverRoute:
    """Retrieves a route"""
    return BaseDefaultApi.subclasses[0]().driver_routes_route_id_get(routeId)


@router.post(
    "/driver_routes/{routeId}",
    responses={
        200: {"model": DriverRoutesRouteIdPost200Response, "description": "Passenger count modified successfully"},
    },
    tags=["default"],
    summary="Modify Passenger Count",
    response_model_by_alias=True,
)
async def driver_routes_route_id_post(
    routeId: str = Path(..., description=""),
    driver_routes_route_id_post_request: DriverRoutesRouteIdPostRequest = Body(None, description=""),
) -> DriverRoutesRouteIdPost200Response:
    ...


@router.post(
    "/driver_routes/to",
    responses={
        200: {"model": DriverRoutesFromPost200Response, "description": "DriverRoute created successfully"},
    },
    tags=["default"],
    summary="Create DriverRoute (To)",
    response_model_by_alias=True,
)
async def driver_routes_to_post(
    route_input: RouteInput = Body(None, description=""),
) -> DriverRoutesFromPost200Response:
    """Creates a new route with an ending point (office) and specified details."""
    return BaseDefaultApi.subclasses[0]().driver_routes_to_post(route_input)


@router.get(
    "/matches",
    responses={
        200: {"model": List[MatchesGet200ResponseInner], "description": "List of matches for the route"},
    },
    tags=["default"],
    summary="Get Matches by DriverRoute ID",
    response_model_by_alias=True,
)
async def matches_get(
    passenger_route_id: str = Query(None, description="", alias="passengerRouteId"),
) -> List[MatchesGet200ResponseInner]:
    """Retrieves a list of matches for a given route ID."""
    return BaseDefaultApi.subclasses[0]().matches_get(passenger_route_id)


@router.get(
    "/offices",
    responses={
        200: {"model": List[OfficesGet200ResponseInner], "description": "List of offices"},
    },
    tags=["default"],
    summary="Get List of Offices",
    response_model_by_alias=True,
)
async def offices_get(
) -> List[OfficesGet200ResponseInner]:
    """Retrieves a list of offices with ID, name, and location (geo)."""
    return BaseDefaultApi.subclasses[0]().offices_get()


@router.get(
    "/passenger_routes/by-users/{userId}",
    responses={
        200: {"model": List[PassengerRoute], "description": "List of driver&#39;s desires"},
    },
    tags=["default"],
    summary="Get Driver&#39;s PassengerRoutes",
    response_model_by_alias=True,
)
async def passenger_routes_by_users_user_id_get(
    userId: str = Path(..., description=""),
) -> List[PassengerRoute]:
    """Retrieves a list of desires reported by the driver, with optional filtering by userId."""
    return BaseDefaultApi.subclasses[0]().passenger_routes_by_users_user_id_get(userId)


@router.post(
    "/passenger_routes/from",
    responses={
        200: {"model": PassengerRoutesFromPost200Response, "description": "PassengerRoute created successfully"},
    },
    tags=["default"],
    summary="Create PassengerRoute (From)",
    response_model_by_alias=True,
)
async def passenger_routes_from_post(
    passenger_route_input: PassengerRouteInput = Body(None, description=""),
) -> PassengerRoutesFromPost200Response:
    """Creates a new desire with a starting point (office) and specified details."""
    return BaseDefaultApi.subclasses[0]().passenger_routes_from_post(passenger_route_input)


@router.delete(
    "/passenger_routes/{passengerRouteId}",
    responses={
        204: {"description": "DriverRoute deleted successfully"},
    },
    tags=["default"],
    summary="Delete DriverRoute",
    response_model_by_alias=True,
)
async def passenger_routes_passenger_route_id_delete(
    passengerRouteId: str = Path(..., description=""),
) -> None:
    """Deletes the specified route."""
    return BaseDefaultApi.subclasses[0]().passenger_routes_passenger_route_id_delete(passengerRouteId)


@router.get(
    "/passenger_routes/{passengerRouteId}",
    responses={
        200: {"model": PassengerRoute, "description": "DriverRoute"},
    },
    tags=["default"],
    summary="Get PassengerRoute",
    response_model_by_alias=True,
)
async def passenger_routes_passenger_route_id_get(
    passengerRouteId: str = Path(..., description=""),
) -> PassengerRoute:
    """Retrieves a desire"""
    return BaseDefaultApi.subclasses[0]().passenger_routes_passenger_route_id_get(passengerRouteId)


@router.post(
    "/passenger_routes/to",
    responses={
        200: {"model": PassengerRoutesFromPost200Response, "description": "PassengerRoute created successfully"},
    },
    tags=["default"],
    summary="Create PassengerRoute (To)",
    response_model_by_alias=True,
)
async def passenger_routes_to_post(
    passenger_route_input: PassengerRouteInput = Body(None, description=""),
) -> PassengerRoutesFromPost200Response:
    """Creates a new desire with an ending point (office) and specified details."""
    return BaseDefaultApi.subclasses[0]().passenger_routes_to_post(passenger_route_input)


@router.get(
    "/passengers",
    responses={
        200: {"model": PassengersGet200Response, "description": "Waiting place information"},
    },
    tags=["default"],
    summary="Get Waiting Place Information",
    response_model_by_alias=True,
)
async def passengers_get(
    contact: str = Query(None, description="", alias="contact"),
    user_id: str = Query(None, description="", alias="userId"),
) -> PassengersGet200Response:
    """Retrieves information about the passenger&#39;s waiting place, including location and estimated waiting time."""
    return BaseDefaultApi.subclasses[0]().passengers_get(contact, user_id)


@router.post(
    "/users",
    responses={
        200: {"model": UsersPost200Response, "description": "Account creation confirmation and userId"},
    },
    tags=["default"],
    summary="Create User Account",
    response_model_by_alias=True,
)
async def users_post(
    users_post_request: UsersPostRequest = Body(None, description=""),
) -> UsersPost200Response:
    """Creates a user account, storing the name, contact, and generating a userId. Returns the userId."""
    return BaseDefaultApi.subclasses[0]().users_post(users_post_request)


@router.get(
    "/users/validation",
    responses={
        200: {"model": UsersPostRequest, "description": "Validation confirmation and user data"},
        404: {"description": "Not found"},
    },
    tags=["default"],
    summary="Validate User",
    response_model_by_alias=True,
)
async def users_validation_get(
    user_id: str = Query(None, description="", alias="userId"),
) -> UsersPostRequest:
    """Verifies the user based on the userId and returns the contact and userId."""
    return BaseDefaultApi.subclasses[0]().users_validation_get(user_id)
