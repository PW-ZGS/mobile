# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from openapi_server.models.driver_route import DriverRoute
from openapi_server.models.driver_routes_from_post200_response import DriverRoutesFromPost200Response
from openapi_server.models.driver_routes_route_id_post200_response import DriverRoutesRouteIdPost200Response
from openapi_server.models.driver_routes_route_id_post_request import DriverRoutesRouteIdPostRequest
from openapi_server.models.matches_get200_response_inner import MatchesGet200ResponseInner
from openapi_server.models.offices_get200_response_inner import OfficesGet200ResponseInner
from openapi_server.models.passenger_route import PassengerRoute
from openapi_server.models.passenger_route_input import PassengerRouteInput
from openapi_server.models.passenger_routes_from_post200_response import PassengerRoutesFromPost200Response
from openapi_server.models.passengers_get200_response import PassengersGet200Response
from openapi_server.models.route_input import RouteInput
from openapi_server.models.users_post200_response import UsersPost200Response
from openapi_server.models.users_post_request import UsersPostRequest


class BaseDefaultApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseDefaultApi.subclasses = BaseDefaultApi.subclasses + (cls,)
    def driver_routes_by_users_user_id_get(
        self,
        userId: str,
    ) -> List[DriverRoute]:
        """Retrieves a list of routes reported by the driver, with optional filtering by userId."""
        ...


    def driver_routes_from_post(
        self,
        route_input: RouteInput,
    ) -> DriverRoutesFromPost200Response:
        """Creates a new route with a starting point (office) and specified details."""
        ...


    def driver_routes_route_id_delete(
        self,
        routeId: str,
    ) -> None:
        """Deletes the specified route."""
        ...


    def driver_routes_route_id_get(
        self,
        routeId: str,
    ) -> DriverRoute:
        """Retrieves a route"""
        ...


    def driver_routes_route_id_post(
        self,
        routeId: str,
        driver_routes_route_id_post_request: DriverRoutesRouteIdPostRequest,
    ) -> DriverRoutesRouteIdPost200Response:
        ...


    def driver_routes_to_post(
        self,
        route_input: RouteInput,
    ) -> DriverRoutesFromPost200Response:
        """Creates a new route with an ending point (office) and specified details."""
        ...


    def matches_get(
        self,
        passenger_route_id: str,
    ) -> List[MatchesGet200ResponseInner]:
        """Retrieves a list of matches for a given route ID."""
        ...


    def offices_get(
        self,
    ) -> List[OfficesGet200ResponseInner]:
        """Retrieves a list of offices with ID, name, and location (geo)."""
        ...


    def passenger_routes_by_users_user_id_get(
        self,
        userId: str,
    ) -> List[PassengerRoute]:
        """Retrieves a list of desires reported by the driver, with optional filtering by userId."""
        ...


    def passenger_routes_from_post(
        self,
        passenger_route_input: PassengerRouteInput,
    ) -> PassengerRoutesFromPost200Response:
        """Creates a new desire with a starting point (office) and specified details."""
        ...


    def passenger_routes_passenger_route_id_delete(
        self,
        passengerRouteId: str,
    ) -> None:
        """Deletes the specified route."""
        ...


    def passenger_routes_passenger_route_id_get(
        self,
        passengerRouteId: str,
    ) -> PassengerRoute:
        """Retrieves a desire"""
        ...


    def passenger_routes_to_post(
        self,
        passenger_route_input: PassengerRouteInput,
    ) -> PassengerRoutesFromPost200Response:
        """Creates a new desire with an ending point (office) and specified details."""
        ...


    def passengers_get(
        self,
        contact: str,
        user_id: str,
    ) -> PassengersGet200Response:
        """Retrieves information about the passenger&#39;s waiting place, including location and estimated waiting time."""
        ...


    def users_post(
        self,
        users_post_request: UsersPostRequest,
    ) -> UsersPost200Response:
        """Creates a user account, storing the name, contact, and generating a userId. Returns the userId."""
        ...


    def users_validation_get(
        self,
        user_id: str,
    ) -> UsersPostRequest:
        """Verifies the user based on the userId and returns the contact and userId."""
        ...
